using System.Text;
using System.Text.Json;
using KITSW.Faculty.Web.Models;

namespace KITSW.Faculty.Web.Services
{
    public class FacultyService
    {
        #region DEMO plumbing - your project already has these (do NOT copy)
        private static readonly HttpClient _client = new HttpClient { Timeout = TimeSpan.FromSeconds(60) };

        // Demo version of your CommonGET(token, path, baseUrl)
        public async Task<string> CommonGET(string token, string path, string baseUrl)
        {
            var response = await _client.GetAsync(baseUrl.TrimEnd('/') + path);
            return await response.Content.ReadAsStringAsync();
        }

        // Demo version of your CommonPOST(data, path, baseUrl)
        public async Task<string> CommonPOST(object data, string path, string baseUrl)
        {
            var content = new StringContent(JsonSerializer.Serialize(data), Encoding.UTF8, "application/json");
            var response = await _client.PostAsync(baseUrl.TrimEnd('/') + path, content);
            return await response.Content.ReadAsStringAsync();
        }

        // Demo version of your existing PopulateFeeType (yours uses Newtonsoft - same result)
        public async Task<List<FeeSetupDropdownModel>> PopulateFeeType(string paymenturl)
        {
            var response = await CommonGET("", "/Fee/PopulateConcessionFeetype", paymenturl);
            using var doc = JsonDocument.Parse(response);
            var list = new List<FeeSetupDropdownModel>();
            if (doc.RootElement.TryGetProperty("result", out var result) && result.ValueKind == JsonValueKind.Array)
            {
                list = JsonSerializer.Deserialize<List<FeeSetupDropdownModel>>(result.GetRawText(),
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            return list;
        }
        #endregion

        #region Partial Fee Setup --santhosh  (NEW - copy this region into your FacultyService)
        public async Task<string> GetPartialFeeStudentDetails(string paymenturl, string rollno, string feetype, string Acyear, string Program)
        {
            try
            {
                var response = await CommonGET("", "/Fee/GetPartialFeeStudentDetails?rollno=" + Uri.EscapeDataString(rollno ?? "")
                                                   + "&feetype=" + Uri.EscapeDataString(feetype ?? "")
                                                   + "&Acyear=" + Uri.EscapeDataString(Acyear ?? "")
                                                   + "&Program=" + Uri.EscapeDataString(Program ?? ""), paymenturl);
                return response.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> InsertPartialFeeStudentDetails(PartialFeeStudentDetailsModel data, string Url)
        {
            try
            {
                var response = await CommonPOST(data, "/Fee/InsertPartialFeeStudentDetails", Url);
                return response.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> BindPartialFeeStudentDetails(string Url)
        {
            try
            {
                var response = await CommonGET("", "/Fee/BindPartialFeeStudentDetails", Url);
                return response.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
