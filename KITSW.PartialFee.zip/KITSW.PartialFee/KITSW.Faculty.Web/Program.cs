var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

var app = builder.Build();

// The KITSW views use "/Faculty/cssnew/...", "~/cssnew/..." and "../cssnew/...".
// Hosting under /Faculty makes all three point to wwwroot/cssnew (same as your server).
app.UsePathBase("/Faculty");
app.UseStaticFiles();
app.UseRouting();

app.MapGet("/", context =>
{
    context.Response.Redirect("/Faculty/Fee/PartialFeeSetup");
    return Task.CompletedTask;
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Fee}/{action=PartialFeeSetup}/{id?}");

app.Run();
