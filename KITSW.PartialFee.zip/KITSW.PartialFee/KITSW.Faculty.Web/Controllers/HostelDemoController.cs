using Microsoft.AspNetCore.Mvc;

namespace KITSW.Faculty.Web.Controllers
{
    /// <summary>
    /// DEMO ONLY - stands in for your Hostel app's roll-number autocomplete
    /// (/hostel/RoomAllocation/Get_Hostel_Students?kamal=...), which the screen already uses.
    /// Do not copy this into your project.
    /// </summary>
    public class HostelDemoController : Controller
    {
        private static readonly string[] Students =
        {
            "24BT001-RAVI KUMAR", "24BT002-SNEHA REDDY", "24BT003-KIRAN NAIK",
            "24MB001-ARJUN RAO", "25MT001-PRIYA SHARMA"
        };

        [HttpGet]
        [Route("/hostel/RoomAllocation/Get_Hostel_Students")]
        public IActionResult Get_Hostel_Students(string kamal)
        {
            var text = (kamal ?? "").Trim();
            var data = Students
                .Where(s => s.Contains(text, StringComparison.OrdinalIgnoreCase))
                .Select(s => new { studentname = s })
                .ToList();
            return Json(data);
        }
    }
}
