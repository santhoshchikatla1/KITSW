using System.Diagnostics;
using KITSW.Faculty.Web.Common;
using KITSW.Faculty.Web.Models;
using KITSW.Faculty.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace KITSW.Faculty.Web.Controllers
{
    public class FeeController : Controller
    {
        private readonly IConfiguration _Iconfiguration;

        public FeeController(IConfiguration configuration)
        {
            _Iconfiguration = configuration;
        }

        // DEMO: your base controller already provides USERID from the logged-in session
        private string USERID => "ADMIN";

        #region Partial Fee Setup --santhosh  (NEW - copy this region into your Fee controller)
        [HttpGet]
        public async Task<IActionResult> PartialFeeSetup()
        {
            // set safe defaults so the view never gets a null list
            ViewBag.FeeType = new List<FeeSetupDropdownModel>();
            try
            {
                string PaymentAPIUrl = _Iconfiguration["PaymentAPIBaseUrl"];

                // Fee Type - reuses existing service method (route /Fee/PopulateConcessionFeetype)
                ViewBag.FeeType = await new FacultyService().PopulateFeeType(PaymentAPIUrl);
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "FacultyWeb-PartialFeeSetup" + ex.Message.Replace("\n", " "));
            }

            // >>> IN YOUR PROJECT: replace these two DEMO lists with the SAME two lines
            // >>> that fill ViewBag.PopulateAcadamic and ViewBag.Program in your Fee Concession action.
            ViewBag.PopulateAcadamic = new List<AcademicYearDropdownModel>
            {
                new AcademicYearDropdownModel { AID = "1", AcademicYear = "2024-25" },
                new AcademicYearDropdownModel { AID = "2", AcademicYear = "2025-26" },
                new AcademicYearDropdownModel { AID = "3", AcademicYear = "2026-27" }
            };
            ViewBag.Program = new List<ProgramDropdownModel>
            {
                new ProgramDropdownModel { ProgramTypeID = "1", ProgramName = "BTech" },
                new ProgramDropdownModel { ProgramTypeID = "2", ProgramName = "MBA" },
                new ProgramDropdownModel { ProgramTypeID = "3", ProgramName = "MTech" }
            };

            return View();
        }

        [HttpGet]
        public async Task<string> GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program)
        {
            string jsonresponse = "";
            try
            {
                string PaymentAPIUrl = _Iconfiguration["PaymentAPIBaseUrl"];
                jsonresponse = await new FacultyService().GetPartialFeeStudentDetails(PaymentAPIUrl, rollno, feetype, Acyear, Program);
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "FacultyWeb-GetPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
            }
            return jsonresponse;
        }

        [HttpPost]
        public async Task<string> InsertPartialFeeStudentDetails([FromBody] PartialFeeStudentDetailsModel data)
        {
            string jsonresponse = "";
            try
            {
                string PaymentAPIUrl = _Iconfiguration["PaymentAPIBaseUrl"];
                data.CreatedBy = USERID;
                jsonresponse = await new FacultyService().InsertPartialFeeStudentDetails(data, PaymentAPIUrl);
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "FacultyWeb-InsertPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
            }
            return jsonresponse;
        }

        [HttpGet]
        public async Task<string> BindPartialFeeStudentDetails()
        {
            string jsonresponse = "";
            try
            {
                string PaymentAPIUrl = _Iconfiguration["PaymentAPIBaseUrl"];
                jsonresponse = await new FacultyService().BindPartialFeeStudentDetails(PaymentAPIUrl);
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "FacultyWeb-BindPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
            }
            return jsonresponse;
        }
        #endregion
    }
}
