namespace KITSW.Faculty.Web.Models
{
    // Same shape as your existing FeeSetupDropdownModel
    public class FeeSetupDropdownModel
    {
        public string categoryid { get; set; }
        public string categorydesc { get; set; }
    }

    // DEMO ONLY - stand-ins for the lists your Concession action puts in ViewBag
    public class AcademicYearDropdownModel
    {
        public string AID { get; set; }
        public string AcademicYear { get; set; }
    }

    public class ProgramDropdownModel
    {
        public string ProgramTypeID { get; set; }
        public string ProgramName { get; set; }
    }

    // NEW - Partial Fee (same as API model)
    public class PartialFeeStudentDetailsModel
    {
        public string ROLLNUMBER { get; set; }
        public string AYEAR { get; set; }
        public string AcademicYear { get; set; }
        public string ProgramId { get; set; }
        public string Program { get; set; }
        public string NAMEOFSTUDENT { get; set; }
        public string FATHERNAME { get; set; }
        public string CategoryID { get; set; }
        public string FEETYPE { get; set; }
        public string SEMISTERID { get; set; }
        public string TOTALAMOUNT { get; set; }
        public string PAIDAMOUNT { get; set; }
        public string BALANCEAMOUNT { get; set; }
        public string PartialFee { get; set; }
        public string Remarks { get; set; }
        public string FeeTerm { get; set; }
        public string CreatedBy { get; set; }
    }

    public class InsertPartialFeeModel
    {
        public string Flag { get; set; }
        public string Message { get; set; }
        public List<PartialFeeStudentDetailsModel> Studentdetails { get; set; } = new List<PartialFeeStudentDetailsModel>();
    }
}
