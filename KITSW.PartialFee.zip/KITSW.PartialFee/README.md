# KITSW – Partial Fee Payment Setup (demo solution, kitsw theme)

A runnable ASP.NET Core 8 solution for checking the **Partial Fee Payment Setup** screen.
It works end to end: Razor View → Web Controller → Web Service → API Controller → Repository.
The repository uses **in-memory sample data**, so no database is needed.

```
KITSW.PartialFee.sln
├─ KITSW.Faculty.Web      (MVC, http://localhost:5100/Faculty/Fee/PartialFeeSetup)
├─ KITSW.Payment.API      (Web API, http://localhost:5101)
├─ Database/PartialFee.sql   (draft table + 3 SPs for your DB team)
└─ run-demo.bat
```

## How to run
**You need:** .NET 8 SDK (Visual Studio 2022 17.8 or later) and internet (the demo loads Bootstrap/DataTables/etc. from CDN).

**Option A – Visual Studio**
1. Open `KITSW.PartialFee.sln`.
2. Right-click the solution → **Configure Startup Projects** → **Multiple startup projects** → set both `KITSW.Payment.API` and `KITSW.Faculty.Web` to **Start**.
3. Press **F5**. The browser opens `http://localhost:5100/Faculty/Fee/PartialFeeSetup`.

**Option B – double-click `run-demo.bat`** (starts the API, then the Web, then opens the browser).

## Sample data to try
| Roll No. | Program | Name |
|---|---|---|
| 24BT001 / 24BT002 / 24BT003 | BTech | Ravi Kumar / Sneha Reddy / Kiran Naik |
| 24MB001 | MBA | Arjun Rao |
| 25MT001 | MTech | Priya Sharma |

Fee per Fee Type (any Academic Year): Tuition 1,50,000 (paid 50,000) · Hostel 80,000 (paid 20,000) · Transport 25,000 (paid 0).
One record (24BT002, 2025-26, BTech, Tuition) is pre-loaded so the grid shows on first load, and saving it again shows the "already set" message.

Test cases: Partial Fee 0 → error · more than the balance → error · no Fee Term → error · valid amount → Update → Submit → grid refreshes · Excel icon → downloads `Partial Fee Setup.xlsx`.

## Getting the exact KITSW look
`Views/Shared/FacultyMainMenu.cshtml` and `FacultySideMenu.cshtml` in this demo are **stand-ins**: they load CDN libraries and `wwwroot/cssnew/kitsw-demo.css`, which recreates the theme. For the pixel-exact look, copy your real folders into `KITSW.Faculty.Web/wwwroot/`: `cssnew`, `jsnew`, `Toasterjs`, `Scripts`, `Content`, `images`, `fonts`. The app runs under `/Faculty`, so the view's existing links (`/Faculty/cssnew/...`, `~/cssnew/...`, `../cssnew/...`) pick them up automatically.

## Moving it into your real KITSW project
Copy only the code marked **NEW** / `#region Partial Fee Setup --santhosh`:

| Demo file | Copy into your project |
|---|---|
| `KITSW.Faculty.Web/Views/Fee/PartialFeeSetup.cshtml` | the whole file → `Views/Fee/` |
| `KITSW.Faculty.Web/Controllers/FeeController.cs` | the region → your Fee controller. In `PartialFeeSetup()`, replace the 2 DEMO lists with the lines that fill `ViewBag.PopulateAcadamic` / `ViewBag.Program` in your Concession action |
| `KITSW.Faculty.Web/Services/FacultyService.cs` | the region only (NOT the DEMO `CommonGET`/`CommonPOST`/`PopulateFeeType`) |
| `KITSW.Faculty.Web/Models/FacultyModels.cs` | `PartialFeeStudentDetailsModel`, `InsertPartialFeeModel` |
| `KITSW.Payment.API/Controllers/FeeController.cs` | the "Partial Fee Setup" region |
| `KITSW.Payment.API/Repository/_RealDb/PaymentsManagement.PartialFee.cs` | the **real DB** version (DBManager + SPs). Add the 3 signatures from `IPaymentsManagement.cs` to your interface |
| `KITSW.Payment.API/Models/PaymentModels.cs` | `PartialFeeStudentDetailsModel`, `InsertPartialFeeModel` |
| `Database/PartialFee.sql` | give to your DB team (replace the `-- TODO` table names) |

**Do NOT copy** (demo stand-ins; your project already has the real ones): `Logs.cs`, `ResponseCodes`, `HostelDemoController.cs`, `FacultyMainMenu.cshtml`, `FacultySideMenu.cshtml`, `kitsw-demo.css`, `PaymentsManagementMock.cs`, `Program.cs`.

## API routes
| Method | Route | Purpose |
|---|---|---|
| GET | `/Fee/PopulateConcessionFeetype` | existing – Fee Type dropdown |
| GET | `/Fee/GetPartialFeeStudentDetails?rollno=&feetype=&Acyear=&Program=` | Get Details |
| POST | `/Fee/InsertPartialFeeStudentDetails` | Submit |
| GET | `/Fee/BindPartialFeeStudentDetails` | Grid |

## SP parameters (see Database/PartialFee.sql)
- **GET_STUDENT_PARTIALFEE_DETAILS** – IN: ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID → ROLLNUMBER, AYEAR, AcademicYear, NAMEOFSTUDENT, FATHERNAME, CategoryID, FEETYPE, SEMISTERID, TOTALAMOUNT, PAIDAMOUNT, BALANCEAMOUNT
- **UMS_INSERT_STUDENT_PARTIAL_FEE** – IN: ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID, SEMISTERID, NAMEOFSTUDENT, FATHERNAME, TOTALAMOUNT, PAIDAMOUNT, PARTIALFEE, REMARKS, MONTHLY_YEARLY, CREATEDBY → set 1: Flag, Message · set 2: grid rows
- **GET_PARTIALFEE_DETAILS** – no input → ROLLNUMBER, AYEAR, AcademicYear, Program, NAMEOFSTUDENT, FATHERNAME, FEETYPE, SEMISTERID, TOTALAMOUNT, PAIDAMOUNT, PARTIALFEE, REMARKS, MONTHLY_YEARLY
