/* =====================================================================
   PARTIAL FEE PAYMENT SETUP  --  SQL DRAFT (SQL Server / T-SQL)
   KITSW  |  kitsw theme  |  --santhosh pattern
   ---------------------------------------------------------------------
   This is a DRAFT for review. Existing tables / SPs are NOT modified.
   Lines marked  -- TODO  must be pointed at your real fee tables
   (the same ones GET_STUDENT_FEECONCESSION reads from).

   SP / PARAMETER CONTRACT USED BY THE C# REPOSITORY
   (names must stay exactly like this, or update the repository too)

   1) GET_STUDENT_PARTIALFEE_DETAILS
        IN : ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID
        OUT: ROLLNUMBER, AYEAR, AcademicYear, NAMEOFSTUDENT, FATHERNAME,
             CategoryID, FEETYPE, SEMISTERID, TOTALAMOUNT, PAIDAMOUNT,
             BALANCEAMOUNT

   2) UMS_INSERT_STUDENT_PARTIAL_FEE
        IN : ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID, SEMISTERID,
             NAMEOFSTUDENT, FATHERNAME, TOTALAMOUNT, PAIDAMOUNT,
             PARTIALFEE, REMARKS, MONTHLY_YEARLY, CREATEDBY
        OUT: Result set 1 -> Flag ('1' success / '0' fail), Message
             Result set 2 -> same columns as SP 3 (refreshed grid)

   3) GET_PARTIALFEE_DETAILS
        IN : (none)
        OUT: ROLLNUMBER, AYEAR, AcademicYear, Program, NAMEOFSTUDENT,
             FATHERNAME, FEETYPE, SEMISTERID, TOTALAMOUNT, PAIDAMOUNT,
             PARTIALFEE, REMARKS, MONTHLY_YEARLY
   ===================================================================== */


/* ---------------------------------------------------------------------
   TABLE : UMS_STUDENT_PARTIAL_FEE
   One permission row per Student + Academic Year + Program + Fee Type.
   STATUS is kept for your existing admin approval screen
   (not shown in this setup screen's grid).
   --------------------------------------------------------------------- */
IF OBJECT_ID('dbo.UMS_STUDENT_PARTIAL_FEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.UMS_STUDENT_PARTIAL_FEE
    (
        PARTIALFEEID     INT IDENTITY(1,1) PRIMARY KEY,
        ROLLNUMBER       VARCHAR(50)    NOT NULL,
        AYEAR            INT            NOT NULL,   -- AID from academic year master
        PROGRAMID        INT            NOT NULL,   -- ProgramTypeID
        CATEGORYID       INT            NOT NULL,   -- Fee Type (CategoryID)
        SEMISTERID       VARCHAR(20)    NULL,
        NAMEOFSTUDENT    VARCHAR(200)   NULL,
        FATHERNAME       VARCHAR(200)   NULL,
        TOTALAMOUNT      DECIMAL(18,2)  NOT NULL,
        PAIDAMOUNT       DECIMAL(18,2)  NOT NULL DEFAULT 0,
        PARTIALFEE       DECIMAL(18,2)  NOT NULL,
        REMARKS          VARCHAR(500)   NULL,
        MONTHLY_YEARLY   CHAR(1)        NULL,       -- 1 = Monthly, 2 = Yearly
        STATUS           VARCHAR(20)    NOT NULL DEFAULT 'Pending', -- used by existing admin approval
        ISACTIVE         BIT            NOT NULL DEFAULT 1,
        CREATEDBY        VARCHAR(50)    NULL,
        CREATEDDATE      DATETIME       NOT NULL DEFAULT GETDATE()
    );

    CREATE INDEX IX_UMS_STUDENT_PARTIAL_FEE_KEY
        ON dbo.UMS_STUDENT_PARTIAL_FEE (ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID, ISACTIVE);
END
GO


/* ---------------------------------------------------------------------
   SP 1 : GET_STUDENT_PARTIALFEE_DETAILS
   Same idea as GET_STUDENT_FEECONCESSION but WITHOUT FEESUBCATID:
   returns totals for the whole Fee Type (all sub-categories summed).
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.GET_STUDENT_PARTIALFEE_DETAILS
    @ROLLNUMBER  VARCHAR(50),
    @AYEAR       VARCHAR(10),
    @PROGRAMID   VARCHAR(10),
    @CATEGORYID  VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        S.ROLLNUMBER,
        F.AYEAR,                                   -- AID
        AY.AcademicYear,                           -- e.g. 2025-26
        S.NAMEOFSTUDENT,
        S.FATHERNAME,
        F.CategoryID,
        FC.CategoryDesc                       AS FEETYPE,
        F.SEMISTERID,
        CAST(SUM(F.TOTALAMOUNT) AS DECIMAL(18,2))                     AS TOTALAMOUNT,
        CAST(SUM(ISNULL(F.PAIDAMOUNT,0)) AS DECIMAL(18,2))            AS PAIDAMOUNT,
        CAST(SUM(F.TOTALAMOUNT) - SUM(ISNULL(F.PAIDAMOUNT,0)) AS DECIMAL(18,2)) AS BALANCEAMOUNT
    FROM  dbo.STUDENT_FEE_DEMAND F            -- TODO: your student fee demand/ledger table
    INNER JOIN dbo.STUDENT_MASTER S           -- TODO: your student master table
            ON S.ROLLNUMBER = F.ROLLNUMBER
    INNER JOIN dbo.MASTER_FEECATEGORY FC      -- TODO: table behind populate_Master_FeeCategory
            ON FC.CategoryID = F.CategoryID
    INNER JOIN dbo.MASTER_ACADEMICYEAR AY     -- TODO: academic year master (AID, AcademicYear)
            ON AY.AID = F.AYEAR
    WHERE F.ROLLNUMBER  = @ROLLNUMBER
      AND F.AYEAR       = @AYEAR
      AND S.PROGRAMID   = @PROGRAMID              -- TODO: confirm program column
      AND F.CategoryID  = @CATEGORYID
    GROUP BY S.ROLLNUMBER, F.AYEAR, AY.AcademicYear, S.NAMEOFSTUDENT, S.FATHERNAME,
             F.CategoryID, FC.CategoryDesc, F.SEMISTERID;
END
GO


/* ---------------------------------------------------------------------
   SP 3 : GET_PARTIALFEE_DETAILS   (grid)
   (created before SP 2 because SP 2 calls it for result set 2)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.GET_PARTIALFEE_DETAILS
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        P.ROLLNUMBER,
        P.AYEAR,
        AY.AcademicYear,
        PR.ProgramName        AS Program,
        P.NAMEOFSTUDENT,
        P.FATHERNAME,
        FC.CategoryDesc       AS FEETYPE,
        P.SEMISTERID,
        P.TOTALAMOUNT,
        P.PAIDAMOUNT,
        P.PARTIALFEE,
        P.REMARKS,
        P.MONTHLY_YEARLY
    FROM dbo.UMS_STUDENT_PARTIAL_FEE P
    LEFT JOIN dbo.MASTER_ACADEMICYEAR AY ON AY.AID = P.AYEAR                 -- TODO
    LEFT JOIN dbo.MASTER_PROGRAMTYPE  PR ON PR.ProgramTypeID = P.PROGRAMID   -- TODO
    LEFT JOIN dbo.MASTER_FEECATEGORY  FC ON FC.CategoryID = P.CATEGORYID     -- TODO
    WHERE P.ISACTIVE = 1
    ORDER BY P.CREATEDDATE DESC;
END
GO


/* ---------------------------------------------------------------------
   SP 2 : UMS_INSERT_STUDENT_PARTIAL_FEE
   Server-side validation (same rules as the screen):
     - Partial Fee > 0
     - Partial Fee <= Outstanding balance (TOTALAMOUNT - PAIDAMOUNT)
     - Only one active permission per Roll + AY + Program + Fee Type
   Result set 1 : Flag, Message
   Result set 2 : refreshed grid (GET_PARTIALFEE_DETAILS)
   --------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE dbo.UMS_INSERT_STUDENT_PARTIAL_FEE
    @ROLLNUMBER      VARCHAR(50),
    @AYEAR           VARCHAR(10),
    @PROGRAMID       VARCHAR(10),
    @CATEGORYID      VARCHAR(10),
    @SEMISTERID      VARCHAR(20),
    @NAMEOFSTUDENT   VARCHAR(200),
    @FATHERNAME      VARCHAR(200),
    @TOTALAMOUNT     VARCHAR(20),
    @PAIDAMOUNT      VARCHAR(20),
    @PARTIALFEE      VARCHAR(20),
    @REMARKS         VARCHAR(500),
    @MONTHLY_YEARLY  VARCHAR(2),
    @CREATEDBY       VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Total   DECIMAL(18,2) = TRY_CAST(@TOTALAMOUNT AS DECIMAL(18,2));
    DECLARE @Paid    DECIMAL(18,2) = ISNULL(TRY_CAST(@PAIDAMOUNT AS DECIMAL(18,2)), 0);
    DECLARE @Partial DECIMAL(18,2) = TRY_CAST(@PARTIALFEE AS DECIMAL(18,2));
    DECLARE @Balance DECIMAL(18,2) = ISNULL(@Total,0) - @Paid;

    IF @Total IS NULL OR @Partial IS NULL
    BEGIN
        SELECT '0' AS Flag, 'Invalid amount values' AS Message;
        EXEC dbo.GET_PARTIALFEE_DETAILS;
        RETURN;
    END

    IF @Partial <= 0
    BEGIN
        SELECT '0' AS Flag, 'Partial fee should be greater than 0' AS Message;
        EXEC dbo.GET_PARTIALFEE_DETAILS;
        RETURN;
    END

    IF @Partial > @Balance
    BEGIN
        SELECT '0' AS Flag, 'Partial fee should not be greater than outstanding balance' AS Message;
        EXEC dbo.GET_PARTIALFEE_DETAILS;
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM dbo.UMS_STUDENT_PARTIAL_FEE
               WHERE ROLLNUMBER = @ROLLNUMBER AND AYEAR = @AYEAR
                 AND PROGRAMID = @PROGRAMID AND CATEGORYID = @CATEGORYID
                 AND ISACTIVE = 1)
    BEGIN
        SELECT '0' AS Flag, 'Partial fee already set for this student and fee type' AS Message;
        EXEC dbo.GET_PARTIALFEE_DETAILS;
        RETURN;
    END

    BEGIN TRY
        INSERT INTO dbo.UMS_STUDENT_PARTIAL_FEE
            (ROLLNUMBER, AYEAR, PROGRAMID, CATEGORYID, SEMISTERID, NAMEOFSTUDENT, FATHERNAME,
             TOTALAMOUNT, PAIDAMOUNT, PARTIALFEE, REMARKS, MONTHLY_YEARLY, CREATEDBY)
        VALUES
            (@ROLLNUMBER, @AYEAR, @PROGRAMID, @CATEGORYID, @SEMISTERID, @NAMEOFSTUDENT, @FATHERNAME,
             @Total, @Paid, @Partial, @REMARKS, @MONTHLY_YEARLY, @CREATEDBY);

        SELECT '1' AS Flag, 'Partial fee details saved successfully' AS Message;
    END TRY
    BEGIN CATCH
        SELECT '0' AS Flag, ERROR_MESSAGE() AS Message;
    END CATCH

    EXEC dbo.GET_PARTIALFEE_DETAILS;
END
GO
