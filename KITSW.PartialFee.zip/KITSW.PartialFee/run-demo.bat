@echo off
REM ================================================================
REM  KITSW Partial Fee Setup - run both projects (needs .NET 8 SDK)
REM ================================================================
cd /d "%~dp0"
echo Starting KITSW Payment API on http://localhost:5101 ...
start "KITSW Payment API" cmd /k dotnet run --project KITSW.Payment.API\KITSW.Payment.API.csproj --launch-profile KITSW.Payment.API
timeout /t 6 /nobreak >nul
echo Starting KITSW Faculty Web on http://localhost:5100 ...
start "KITSW Faculty Web" cmd /k dotnet run --project KITSW.Faculty.Web\KITSW.Faculty.Web.csproj --launch-profile KITSW.Faculty.Web
timeout /t 10 /nobreak >nul
start "" http://localhost:5100/Faculty/Fee/PartialFeeSetup
