namespace KITSW.Payment.API.Models
{
    // Same shape as your existing FeeSetupDropdownModel (categoryid / categorydesc)
    public class FeeSetupDropdownModel
    {
        public string categoryid { get; set; }
        public string categorydesc { get; set; }
    }

    // NEW - Partial Fee
    public class PartialFeeStudentDetailsModel
    {
        public string ROLLNUMBER { get; set; }
        public string AYEAR { get; set; }           // AID (academic year id)
        public string AcademicYear { get; set; }    // display text e.g. 2025-26
        public string ProgramId { get; set; }       // ProgramTypeID
        public string Program { get; set; }         // display text
        public string NAMEOFSTUDENT { get; set; }
        public string FATHERNAME { get; set; }
        public string CategoryID { get; set; }      // Fee Type id
        public string FEETYPE { get; set; }         // Fee Type text
        public string SEMISTERID { get; set; }
        public string TOTALAMOUNT { get; set; }
        public string PAIDAMOUNT { get; set; }
        public string BALANCEAMOUNT { get; set; }   // TOTALAMOUNT - PAIDAMOUNT
        public string PartialFee { get; set; }
        public string Remarks { get; set; }
        public string FeeTerm { get; set; }         // 1 = Monthly, 2 = Yearly
        public string CreatedBy { get; set; }
    }

    public class InsertPartialFeeModel
    {
        public string Flag { get; set; }
        public string Message { get; set; }
        public List<PartialFeeStudentDetailsModel> Studentdetails { get; set; } = new List<PartialFeeStudentDetailsModel>();
    }

    // DEMO copy of your ResponseCodes. SuccessCode must be 200 (the screen checks obj.code != 200).
    // Your project already has this class - do not copy it there.
    public class ResponseCodes
    {
        public int SuccessCode { get; } = 200;
        public string SuccessStatus { get; } = "Success";
        public int ErrorCode { get; } = 500;
        public string InvalidStatus { get; } = "Something went wrong";
        public int DataNotAvailableCode { get; } = 204;
        public string DataNotAvailable { get; } = "No Data Found";
    }
}
