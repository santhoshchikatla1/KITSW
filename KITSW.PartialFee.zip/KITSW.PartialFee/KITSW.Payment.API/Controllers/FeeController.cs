using System.Diagnostics;
using KITSW.Payment.API.Common;
using KITSW.Payment.API.Models;
using KITSW.Payment.API.Repository;
using Microsoft.AspNetCore.Mvc;

namespace KITSW.Payment.API.Controllers
{
    [Route("Fee")]
    public class FeeController : ControllerBase
    {
        private readonly IPaymentsManagement _PaymentsManagement;

        public FeeController(IPaymentsManagement paymentsManagement)
        {
            _PaymentsManagement = paymentsManagement;
        }

        #region Concession FeeSetup --santhosh  (EXISTING - copied unchanged, used for Fee Type dropdown)
        [HttpGet, Route("PopulateConcessionFeetype")]
        public IActionResult PopulateConcessionFeetype()
        {
            ResponseCodes responseCodes = new ResponseCodes();
            var result = _PaymentsManagement.PopulateConcessionFeetype();
            if (result == null)
            {
                return Ok(new
                {
                    Code = responseCodes.ErrorCode,
                    Status = responseCodes.InvalidStatus,
                    Result = ""
                });
            }
            if (result.Count == 0)
            {
                return Ok(new
                {
                    Code = responseCodes.DataNotAvailableCode,
                    Status = responseCodes.DataNotAvailable,
                    Result = result
                });
            }
            return Ok(new
            {
                Code = responseCodes.SuccessCode,
                Status = responseCodes.SuccessStatus,
                Result = result
            });
        }
        #endregion

        #region Partial Fee Setup --santhosh  (NEW)
        [HttpGet, Route("GetPartialFeeStudentDetails")]
        public IActionResult GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program)
        {
            ResponseCodes responseCodes = new ResponseCodes();
            try
            {
                var result = _PaymentsManagement.GetPartialFeeStudentDetails(rollno, feetype, Acyear, Program);
                if (result == null)
                {
                    return Ok(new
                    {
                        Code = responseCodes.ErrorCode,
                        Status = responseCodes.InvalidStatus,
                        Result = ""
                    });
                }
                if (result.Count == 0)
                {
                    return Ok(new
                    {
                        Code = responseCodes.DataNotAvailableCode,
                        Status = responseCodes.DataNotAvailable,
                        Result = result
                    });
                }
                return Ok(new
                {
                    Code = responseCodes.SuccessCode,
                    Status = responseCodes.SuccessStatus,
                    Result = result
                });
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "PaymentAPI-GetPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
                return Ok(new
                {
                    Code = responseCodes.ErrorCode,
                    Status = responseCodes.InvalidStatus,
                    Result = ""
                });
            }
        }

        [HttpPost, Route("InsertPartialFeeStudentDetails")]
        public IActionResult InsertPartialFeeStudentDetails([FromBody] PartialFeeStudentDetailsModel objrequest)
        {
            ResponseCodes responseCodes = new ResponseCodes();
            InsertPartialFeeModel result = new InsertPartialFeeModel();
            try
            {
                result = _PaymentsManagement.InsertStudentPartialFeeDetails(objrequest);

                if (result == null)
                {
                    return Ok(new
                    {
                        Code = responseCodes.ErrorCode,
                        Status = responseCodes.InvalidStatus,
                        Result = ""
                    });
                }
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "PaymentAPI-InsertPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
                return Ok(new
                {
                    Code = responseCodes.ErrorCode,
                    Status = responseCodes.InvalidStatus,
                    Result = ""
                });
            }
            // Flag "0" (validation / duplicate) is returned with SuccessCode;
            // the screen shows result.message when flag != "1" (same as Concession)
            return Ok(new
            {
                Code = responseCodes.SuccessCode,
                Status = responseCodes.SuccessStatus,
                Result = result
            });
        }

        [HttpGet, Route("BindPartialFeeStudentDetails")]
        public IActionResult BindPartialFeeStudentDetails()
        {
            ResponseCodes responseCodes = new ResponseCodes();
            InsertPartialFeeModel result = new InsertPartialFeeModel();
            try
            {
                result = _PaymentsManagement.BindPartialFeeStudentDetails();

                if (result == null)
                {
                    return Ok(new
                    {
                        Code = responseCodes.ErrorCode,
                        Status = responseCodes.InvalidStatus,
                        Result = ""
                    });
                }
                if (result.Studentdetails == null || result.Studentdetails.Count == 0)
                {
                    return Ok(new
                    {
                        Code = responseCodes.DataNotAvailableCode,
                        Status = responseCodes.DataNotAvailable,
                        Result = result
                    });
                }
            }
            catch (Exception ex)
            {
                Logs.LogException(new StackTrace(ex, true).ToString(), "101", "PaymentAPI-BindPartialFeeStudentDetails" + ex.Message.Replace("\n", " "));
                return Ok(new
                {
                    Code = responseCodes.ErrorCode,
                    Status = responseCodes.InvalidStatus,
                    Result = ""
                });
            }
            return Ok(new
            {
                Code = responseCodes.SuccessCode,
                Status = responseCodes.SuccessStatus,
                Result = result
            });
        }
        #endregion
    }
}
