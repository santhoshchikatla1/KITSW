using KITSW.Payment.API.Repository;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();   // System.Text.Json, camelCase (same as Concession: obj.code / obj.result)

// DEMO: in-memory data. In your project _PaymentsManagement is the real DB repository.
builder.Services.AddSingleton<IPaymentsManagement, PaymentsManagementMock>();

var app = builder.Build();

app.MapGet("/", () => "KITSW Payment API (demo) is running. Try /Fee/PopulateConcessionFeetype");
app.MapControllers();

app.Run();
