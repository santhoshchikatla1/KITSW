using KITSW.Payment.API.Models;

namespace KITSW.Payment.API.Repository
{
    // Add the 3 "Partial Fee" signatures to your existing _PaymentsManagement interface.
    public interface IPaymentsManagement
    {
        // existing (already in your project - unchanged)
        List<FeeSetupDropdownModel> PopulateConcessionFeetype();

        // NEW - Partial Fee Setup
        List<PartialFeeStudentDetailsModel> GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program);
        InsertPartialFeeModel InsertStudentPartialFeeDetails(PartialFeeStudentDetailsModel objrequest);
        InsertPartialFeeModel BindPartialFeeStudentDetails();
    }
}
