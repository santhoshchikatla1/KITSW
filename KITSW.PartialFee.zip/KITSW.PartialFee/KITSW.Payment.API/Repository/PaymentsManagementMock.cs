using System.Globalization;
using KITSW.Payment.API.Models;

namespace KITSW.Payment.API.Repository
{
    /// <summary>
    /// DEMO ONLY - in-memory data so the screen can be run without the database.
    /// Implements the same rules as the draft SPs in Database/PartialFee.sql.
    /// Your real implementation is Repository/_RealDb/PaymentsManagement.PartialFee.cs (DBManager + SPs).
    /// </summary>
    public class PaymentsManagementMock : IPaymentsManagement
    {
        private readonly object _lock = new object();

        private static readonly Dictionary<string, string> AcademicYears = new()
        {
            ["1"] = "2024-25", ["2"] = "2025-26", ["3"] = "2026-27"
        };

        private static readonly Dictionary<string, string> Programs = new()
        {
            ["1"] = "BTech", ["2"] = "MBA", ["3"] = "MTech"
        };

        private static readonly Dictionary<string, string> FeeTypes = new()
        {
            ["1"] = "Tuition Fee", ["2"] = "Hostel Fee", ["3"] = "Transport Fee"
        };

        private record Student(string RollNo, string Name, string Father, string ProgramId, string Semester);

        private static readonly List<Student> Students = new()
        {
            new("24BT001", "RAVI KUMAR",   "SURESH KUMAR",  "1", "3"),
            new("24BT002", "SNEHA REDDY",  "MOHAN REDDY",   "1", "3"),
            new("24BT003", "KIRAN NAIK",   "RAMESH NAIK",   "1", "3"),
            new("24MB001", "ARJUN RAO",    "SRINIVAS RAO",  "2", "1"),
            new("25MT001", "PRIYA SHARMA", "VIJAY SHARMA",  "3", "1")
        };

        // Fee demand per fee type: total / paid (same for every academic year in the demo)
        private static readonly Dictionary<string, (decimal Total, decimal Paid)> FeeDemand = new()
        {
            ["1"] = (150000m, 50000m),
            ["2"] = (80000m, 20000m),
            ["3"] = (25000m, 0m)
        };

        // table UMS_STUDENT_PARTIAL_FEE (demo)
        private readonly List<PartialFeeStudentDetailsModel> _partialFees = new()
        {
            new PartialFeeStudentDetailsModel
            {
                ROLLNUMBER = "24BT002", AYEAR = "2", ProgramId = "1", CategoryID = "1",
                NAMEOFSTUDENT = "SNEHA REDDY", FATHERNAME = "MOHAN REDDY", SEMISTERID = "3",
                TOTALAMOUNT = "150000.00", PAIDAMOUNT = "50000.00", PartialFee = "40000.00",
                Remarks = "Financial difficulty - approved by Principal", FeeTerm = "2", CreatedBy = "ADMIN"
            }
        };

        public List<FeeSetupDropdownModel> PopulateConcessionFeetype()
        {
            return FeeTypes.Select(f => new FeeSetupDropdownModel { categoryid = f.Key, categorydesc = f.Value }).ToList();
        }

        // = GET_STUDENT_PARTIALFEE_DETAILS
        public List<PartialFeeStudentDetailsModel> GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program)
        {
            var result = new List<PartialFeeStudentDetailsModel>();
            var st = Students.FirstOrDefault(s => string.Equals(s.RollNo, rollno?.Trim(), StringComparison.OrdinalIgnoreCase)
                                                  && s.ProgramId == Program);
            if (st == null || feetype == null || !FeeDemand.ContainsKey(feetype) || Acyear == null || !AcademicYears.ContainsKey(Acyear))
                return result;

            var fee = FeeDemand[feetype];
            result.Add(new PartialFeeStudentDetailsModel
            {
                ROLLNUMBER = st.RollNo,
                AYEAR = Acyear,
                AcademicYear = AcademicYears[Acyear],
                NAMEOFSTUDENT = st.Name,
                FATHERNAME = st.Father,
                CategoryID = feetype,
                FEETYPE = FeeTypes[feetype],
                SEMISTERID = st.Semester,
                TOTALAMOUNT = fee.Total.ToString("0.00", CultureInfo.InvariantCulture),
                PAIDAMOUNT = fee.Paid.ToString("0.00", CultureInfo.InvariantCulture),
                BALANCEAMOUNT = (fee.Total - fee.Paid).ToString("0.00", CultureInfo.InvariantCulture)
            });
            return result;
        }

        // = UMS_INSERT_STUDENT_PARTIAL_FEE
        public InsertPartialFeeModel InsertStudentPartialFeeDetails(PartialFeeStudentDetailsModel r)
        {
            lock (_lock)
            {
                var result = new InsertPartialFeeModel();

                bool okTotal = decimal.TryParse(r.TOTALAMOUNT, NumberStyles.Number, CultureInfo.InvariantCulture, out var total);
                decimal.TryParse(r.PAIDAMOUNT, NumberStyles.Number, CultureInfo.InvariantCulture, out var paid);
                bool okPartial = decimal.TryParse(r.PartialFee, NumberStyles.Number, CultureInfo.InvariantCulture, out var partial);

                if (!okTotal || !okPartial)
                    Fail(result, "Invalid amount values");
                else if (partial <= 0)
                    Fail(result, "Partial fee should be greater than 0");
                else if (partial > total - paid)
                    Fail(result, "Partial fee should not be greater than outstanding balance");
                else if (_partialFees.Any(p => p.ROLLNUMBER == r.ROLLNUMBER && p.AYEAR == r.AYEAR
                                               && p.ProgramId == r.ProgramId && p.CategoryID == r.CategoryID))
                    Fail(result, "Partial fee already set for this student and fee type");
                else
                {
                    _partialFees.Add(new PartialFeeStudentDetailsModel
                    {
                        ROLLNUMBER = r.ROLLNUMBER, AYEAR = r.AYEAR, ProgramId = r.ProgramId, CategoryID = r.CategoryID,
                        SEMISTERID = r.SEMISTERID, NAMEOFSTUDENT = r.NAMEOFSTUDENT, FATHERNAME = r.FATHERNAME,
                        TOTALAMOUNT = total.ToString("0.00", CultureInfo.InvariantCulture),
                        PAIDAMOUNT = paid.ToString("0.00", CultureInfo.InvariantCulture),
                        PartialFee = partial.ToString("0.00", CultureInfo.InvariantCulture),
                        Remarks = r.Remarks, FeeTerm = r.FeeTerm, CreatedBy = r.CreatedBy
                    });
                    result.Flag = "1";
                    result.Message = "Partial fee details saved successfully";
                }

                result.Studentdetails = Grid();   // result set 2
                return result;
            }
        }

        // = GET_PARTIALFEE_DETAILS
        public InsertPartialFeeModel BindPartialFeeStudentDetails()
        {
            lock (_lock)
            {
                return new InsertPartialFeeModel { Flag = "1", Studentdetails = Grid() };
            }
        }

        private static void Fail(InsertPartialFeeModel m, string msg)
        {
            m.Flag = "0";
            m.Message = msg;
        }

        private List<PartialFeeStudentDetailsModel> Grid()
        {
            return _partialFees.AsEnumerable().Reverse().Select(p => new PartialFeeStudentDetailsModel
            {
                ROLLNUMBER = p.ROLLNUMBER,
                AYEAR = p.AYEAR,
                AcademicYear = AcademicYears.GetValueOrDefault(p.AYEAR ?? "", p.AYEAR),
                Program = Programs.GetValueOrDefault(p.ProgramId ?? "", p.ProgramId),
                NAMEOFSTUDENT = p.NAMEOFSTUDENT,
                FATHERNAME = p.FATHERNAME,
                FEETYPE = FeeTypes.GetValueOrDefault(p.CategoryID ?? "", p.CategoryID),
                SEMISTERID = p.SEMISTERID,
                TOTALAMOUNT = p.TOTALAMOUNT,
                PAIDAMOUNT = p.PAIDAMOUNT,
                PartialFee = p.PartialFee,
                Remarks = p.Remarks,
                FeeTerm = p.FeeTerm
            }).ToList();
        }
    }
}
