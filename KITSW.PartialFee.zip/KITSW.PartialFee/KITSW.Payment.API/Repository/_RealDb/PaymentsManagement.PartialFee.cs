// REAL DB repository for YOUR project (uses DBManager + SPs). Not compiled in the demo solution.
// Paste the region into your existing repository class.

// =====================================================================
//  PARTIAL FEE SETUP  --  API REPOSITORY  (kitsw theme)
//  Add inside the SAME repository class that has
//  "#region concession fee setup --santhosh" (uses dbManager).
//  Also add the 3 method signatures to the _PaymentsManagement interface:
//
//      List<PartialFeeStudentDetailsModel> GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program);
//      InsertPartialFeeModel InsertStudentPartialFeeDetails(PartialFeeStudentDetailsModel objrequest);
//      InsertPartialFeeModel BindPartialFeeStudentDetails();
//
//  Fee Type dropdown reuses existing PopulateConcessionFeetype() - unchanged.
// =====================================================================

#region Partial Fee Setup --santhosh
public List<PartialFeeStudentDetailsModel> GetPartialFeeStudentDetails(string rollno, string feetype, string Acyear, string Program)
{
    List<PartialFeeStudentDetailsModel> result = new List<PartialFeeStudentDetailsModel>();
    IDataReader dr = null;
    try
    {
        if (dbManager == null)
        {
            dbManager = new DBManager.DBManager();
        }
        dbManager.Open();
        dbManager.CreateParameters(4);

        dbManager.AddParameters(0, "ROLLNUMBER", rollno, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(1, "AYEAR", Acyear, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(2, "PROGRAMID", Program, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(3, "CATEGORYID", feetype, ParameterDirection.Input, DaoConstants.InParamSize);
        dr = dbManager.ExecuteReader(CommandType.StoredProcedure, "GET_STUDENT_PARTIALFEE_DETAILS");

        while (dr.Read())
        {
            PartialFeeStudentDetailsModel item = new PartialFeeStudentDetailsModel
            {
                ROLLNUMBER = dr["ROLLNUMBER"] == DBNull.Value ? null : dr["ROLLNUMBER"].ToString(),
                AYEAR = dr["AYEAR"] == DBNull.Value ? null : dr["AYEAR"].ToString(),
                AcademicYear = dr["AcademicYear"] == DBNull.Value ? null : dr["AcademicYear"].ToString(),
                NAMEOFSTUDENT = dr["NAMEOFSTUDENT"] == DBNull.Value ? null : dr["NAMEOFSTUDENT"].ToString(),
                FATHERNAME = dr["FATHERNAME"] == DBNull.Value ? null : dr["FATHERNAME"].ToString(),
                CategoryID = dr["CategoryID"] == DBNull.Value ? null : dr["CategoryID"].ToString(),
                FEETYPE = dr["FEETYPE"] == DBNull.Value ? null : dr["FEETYPE"].ToString(),
                SEMISTERID = dr["SEMISTERID"] == DBNull.Value ? null : dr["SEMISTERID"].ToString(),
                TOTALAMOUNT = dr["TOTALAMOUNT"] == DBNull.Value ? null : dr["TOTALAMOUNT"].ToString(),
                PAIDAMOUNT = dr["PAIDAMOUNT"] == DBNull.Value ? null : dr["PAIDAMOUNT"].ToString(),
                BALANCEAMOUNT = dr["BALANCEAMOUNT"] == DBNull.Value ? null : dr["BALANCEAMOUNT"].ToString()
            };
            result.Add(item);
        }
        return result;
    }
    finally
    {
        if (dr != null && !dr.IsClosed)
        {
            dr.Close();
        }
    }
}

public InsertPartialFeeModel InsertStudentPartialFeeDetails(PartialFeeStudentDetailsModel objrequest)
{
    InsertPartialFeeModel result = new InsertPartialFeeModel();
    IDataReader dr = null;
    try
    {
        if (dbManager == null)
        {
            dbManager = new DBManager.DBManager();
        }
        dbManager.Open();
        dbManager.CreateParameters(13);

        dbManager.AddParameters(0, "ROLLNUMBER", objrequest.ROLLNUMBER, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(1, "AYEAR", objrequest.AYEAR, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(2, "PROGRAMID", objrequest.ProgramId, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(3, "CATEGORYID", objrequest.CategoryID, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(4, "SEMISTERID", objrequest.SEMISTERID, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(5, "NAMEOFSTUDENT", objrequest.NAMEOFSTUDENT, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(6, "FATHERNAME", objrequest.FATHERNAME, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(7, "TOTALAMOUNT", objrequest.TOTALAMOUNT, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(8, "PAIDAMOUNT", objrequest.PAIDAMOUNT, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(9, "PARTIALFEE", objrequest.PartialFee, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(10, "REMARKS", objrequest.Remarks, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(11, "MONTHLY_YEARLY", objrequest.FeeTerm, ParameterDirection.Input, DaoConstants.InParamSize);
        dbManager.AddParameters(12, "CREATEDBY", objrequest.CreatedBy, ParameterDirection.Input, DaoConstants.InParamSize);

        dr = dbManager.ExecuteReader(CommandType.StoredProcedure, "UMS_INSERT_STUDENT_PARTIAL_FEE");

        if (dr.Read())
        {
            result.Flag = dr["Flag"] == DBNull.Value ? null : dr["Flag"].ToString();
            result.Message = dr["Message"] == DBNull.Value ? null : dr["Message"].ToString();
        }
        if (dr.NextResult())
        {
            result.Studentdetails = ReadPartialFeeGridRows(dr);
        }
        return result;
    }
    finally
    {
        if (dr != null && !dr.IsClosed)
        {
            dr.Close();
        }
    }
}

public InsertPartialFeeModel BindPartialFeeStudentDetails()
{
    InsertPartialFeeModel result = new InsertPartialFeeModel();
    IDataReader dr = null;
    try
    {
        if (dbManager == null)
        {
            dbManager = new DBManager.DBManager();
        }
        dbManager.Open();

        dr = dbManager.ExecuteReader(CommandType.StoredProcedure, "GET_PARTIALFEE_DETAILS");

        // NOTE: no "if (dr.Read())" before the loop - that skips the first row
        result.Flag = "1";
        result.Studentdetails = ReadPartialFeeGridRows(dr);
        return result;
    }
    finally
    {
        if (dr != null && !dr.IsClosed)
        {
            dr.Close();
        }
    }
}

// Shared mapper for GET_PARTIALFEE_DETAILS columns (grid)
private List<PartialFeeStudentDetailsModel> ReadPartialFeeGridRows(IDataReader dr)
{
    List<PartialFeeStudentDetailsModel> studentdetails = new List<PartialFeeStudentDetailsModel>();
    while (dr.Read())
    {
        PartialFeeStudentDetailsModel item = new PartialFeeStudentDetailsModel
        {
            ROLLNUMBER = dr["ROLLNUMBER"] == DBNull.Value ? null : dr["ROLLNUMBER"].ToString(),
            AYEAR = dr["AYEAR"] == DBNull.Value ? null : dr["AYEAR"].ToString(),
            AcademicYear = dr["AcademicYear"] == DBNull.Value ? null : dr["AcademicYear"].ToString(),
            Program = dr["Program"] == DBNull.Value ? null : dr["Program"].ToString(),
            NAMEOFSTUDENT = dr["NAMEOFSTUDENT"] == DBNull.Value ? null : dr["NAMEOFSTUDENT"].ToString(),
            FATHERNAME = dr["FATHERNAME"] == DBNull.Value ? null : dr["FATHERNAME"].ToString(),
            FEETYPE = dr["FEETYPE"] == DBNull.Value ? null : dr["FEETYPE"].ToString(),
            SEMISTERID = dr["SEMISTERID"] == DBNull.Value ? null : dr["SEMISTERID"].ToString(),
            TOTALAMOUNT = dr["TOTALAMOUNT"] == DBNull.Value ? null : dr["TOTALAMOUNT"].ToString(),
            PAIDAMOUNT = dr["PAIDAMOUNT"] == DBNull.Value ? null : dr["PAIDAMOUNT"].ToString(),
            PartialFee = dr["PARTIALFEE"] == DBNull.Value ? null : dr["PARTIALFEE"].ToString(),
            Remarks = dr["REMARKS"] == DBNull.Value ? null : dr["REMARKS"].ToString(),
            FeeTerm = dr["MONTHLY_YEARLY"] == DBNull.Value ? null : dr["MONTHLY_YEARLY"].ToString()
        };
        studentdetails.Add(item);
    }
    return studentdetails;
}
#endregion
