namespace KITSW.Payment.API.Common
{
    // DEMO stand-in for your existing Logs class (same signature). Writes to the console.
    public static class Logs
    {
        public static void LogException(string stackTrace, string code, string message)
        {
            Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {code} {message}{Environment.NewLine}{stackTrace}");
        }
    }
}
